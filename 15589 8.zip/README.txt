SITE PRESTOT — Couverture & Rénovation

Fichiers :
- index.html : page complète
- style.css : design responsive
- script.js : menu mobile + formulaire de démonstration

À personnaliser :
- téléphone et email dans index.html
- photos (les images actuelles utilisent des URLs Unsplash)
- textes, prestations et coordonnées
- connecter le formulaire à un vrai service d'envoi

Pour tester : ouvre index.html dans un navigateur.
