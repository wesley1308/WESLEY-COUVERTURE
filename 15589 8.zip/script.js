const menu=document.querySelector(".menu-btn"), nav=document.querySelector(".nav");
menu.addEventListener("click",()=>nav.classList.toggle("open"));
document.querySelectorAll(".nav a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));
document.getElementById("year").textContent=new Date().getFullYear();
document.getElementById("quoteForm").addEventListener("submit",e=>{
  e.preventDefault();
  document.getElementById("formMessage").textContent="Merci ! Votre demande est prête à être envoyée. Remplacez cette démo par votre adresse e-mail ou votre formulaire professionnel.";
});
